--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bond;
--
-- Name: bond; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bond WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Russian_Russia.1251' LC_CTYPE = 'Russian_Russia.1251';


ALTER DATABASE bond OWNER TO postgres;

\connect bond

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name:  List_of_Services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public." List_of_Services" (
    id_service integer NOT NULL,
    id_customer integer,
    id_admin integer,
    id_employee integer,
    "Total_cost" text
);


ALTER TABLE public." List_of_Services" OWNER TO postgres;

--
-- Name: Admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Admin" (
    "Name_Admin" text,
    "ID_Admin" integer NOT NULL,
    "Phone_Admin" text
);


ALTER TABLE public."Admin" OWNER TO postgres;

--
-- Name: Cleaning; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Cleaning" (
    id_cleaning integer NOT NULL,
    id_employee integer,
    id_admin integer,
    "Cleaning_Floor" integer,
    "Cleaning_Date" date
);


ALTER TABLE public."Cleaning" OWNER TO postgres;

--
-- Name: Contract; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Contract" (
    id_contract integer NOT NULL,
    id_employee integer,
    id_admin integer,
    work_conditions text
);


ALTER TABLE public."Contract" OWNER TO postgres;

--
-- Name: Customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Customer" (
    "Name_Customer" text,
    "City_Customer" text,
    "ID_Customer" integer NOT NULL,
    "Passport_Number_Customer" integer
);


ALTER TABLE public."Customer" OWNER TO postgres;

--
-- Name: Hotel_Employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Hotel_Employee" (
    "ID_Employee" integer NOT NULL,
    "Name_Employee" text,
    "Position_Employee" text
);


ALTER TABLE public."Hotel_Employee" OWNER TO postgres;

--
-- Name: Residence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Residence" (
    id_residence integer NOT NULL,
    id_room integer,
    id_customer integer,
    id_admin integer,
    residence_conditions text,
    residence_date_in date,
    residence_date_out date
);


ALTER TABLE public."Residence" OWNER TO postgres;

--
-- Name: Room; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Room" (
    "ID_Room" integer NOT NULL,
    "Floor_Room" integer,
    "Type_Room" text,
    "CPN_Room" text
);


ALTER TABLE public."Room" OWNER TO postgres;

--
-- Name: Service; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Service" (
    id_service integer NOT NULL,
    service_type "char"[],
    service_cost "char"[]
);


ALTER TABLE public."Service" OWNER TO postgres;

--
-- Data for Name:  List_of_Services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public." List_of_Services" (id_service, id_customer, id_admin, id_employee, "Total_cost") FROM stdin;
\.
COPY public." List_of_Services" (id_service, id_customer, id_admin, id_employee, "Total_cost") FROM '$$PATH$$/2880.dat';

--
-- Data for Name: Admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Admin" ("Name_Admin", "ID_Admin", "Phone_Admin") FROM stdin;
\.
COPY public."Admin" ("Name_Admin", "ID_Admin", "Phone_Admin") FROM '$$PATH$$/2873.dat';

--
-- Data for Name: Cleaning; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Cleaning" (id_cleaning, id_employee, id_admin, "Cleaning_Floor", "Cleaning_Date") FROM stdin;
\.
COPY public."Cleaning" (id_cleaning, id_employee, id_admin, "Cleaning_Floor", "Cleaning_Date") FROM '$$PATH$$/2878.dat';

--
-- Data for Name: Contract; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Contract" (id_contract, id_employee, id_admin, work_conditions) FROM stdin;
\.
COPY public."Contract" (id_contract, id_employee, id_admin, work_conditions) FROM '$$PATH$$/2879.dat';

--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Customer" ("Name_Customer", "City_Customer", "ID_Customer", "Passport_Number_Customer") FROM stdin;
\.
COPY public."Customer" ("Name_Customer", "City_Customer", "ID_Customer", "Passport_Number_Customer") FROM '$$PATH$$/2874.dat';

--
-- Data for Name: Hotel_Employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Hotel_Employee" ("ID_Employee", "Name_Employee", "Position_Employee") FROM stdin;
\.
COPY public."Hotel_Employee" ("ID_Employee", "Name_Employee", "Position_Employee") FROM '$$PATH$$/2875.dat';

--
-- Data for Name: Residence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Residence" (id_residence, id_room, id_customer, id_admin, residence_conditions, residence_date_in, residence_date_out) FROM stdin;
\.
COPY public."Residence" (id_residence, id_room, id_customer, id_admin, residence_conditions, residence_date_in, residence_date_out) FROM '$$PATH$$/2877.dat';

--
-- Data for Name: Room; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Room" ("ID_Room", "Floor_Room", "Type_Room", "CPN_Room") FROM stdin;
\.
COPY public."Room" ("ID_Room", "Floor_Room", "Type_Room", "CPN_Room") FROM '$$PATH$$/2876.dat';

--
-- Data for Name: Service; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Service" (id_service, service_type, service_cost) FROM stdin;
\.
COPY public."Service" (id_service, service_type, service_cost) FROM '$$PATH$$/2881.dat';

--
-- Name:  List_of_Services  List_of_Services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public." List_of_Services"
    ADD CONSTRAINT " List_of_Services_pkey" PRIMARY KEY (id_service);


--
-- Name: Cleaning Cleaning_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Cleaning"
    ADD CONSTRAINT "Cleaning_pkey" PRIMARY KEY (id_cleaning);


--
-- Name: Contract Contract_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contract"
    ADD CONSTRAINT "Contract_pkey" PRIMARY KEY (id_contract);


--
-- Name: Hotel_Employee Hotel_Employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Hotel_Employee"
    ADD CONSTRAINT "Hotel_Employee_pkey" PRIMARY KEY ("ID_Employee");


--
-- Name: Residence Residence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Residence"
    ADD CONSTRAINT "Residence_pkey" PRIMARY KEY (id_residence);


--
-- Name: Service Service_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT "Service_pkey" PRIMARY KEY (id_service);


--
-- Name: Admin Администратор_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admin"
    ADD CONSTRAINT "Администратор_pkey" PRIMARY KEY ("ID_Admin");


--
-- Name: Customer Клиент_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Клиент_pkey" PRIMARY KEY ("ID_Customer");


--
-- Name: Room Номер_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Room"
    ADD CONSTRAINT "Номер_pkey" PRIMARY KEY ("ID_Room");


--
-- Name: Residence id_admin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Residence"
    ADD CONSTRAINT id_admin FOREIGN KEY (id_admin) REFERENCES public."Admin"("ID_Admin");


--
-- Name: Cleaning id_admin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Cleaning"
    ADD CONSTRAINT id_admin FOREIGN KEY (id_admin) REFERENCES public."Admin"("ID_Admin");


--
-- Name: Contract id_admin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contract"
    ADD CONSTRAINT id_admin FOREIGN KEY (id_admin) REFERENCES public."Admin"("ID_Admin");


--
-- Name:  List_of_Services id_admin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public." List_of_Services"
    ADD CONSTRAINT id_admin FOREIGN KEY (id_admin) REFERENCES public."Admin"("ID_Admin");


--
-- Name: Residence id_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Residence"
    ADD CONSTRAINT id_customer FOREIGN KEY (id_customer) REFERENCES public."Customer"("ID_Customer");


--
-- Name:  List_of_Services id_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public." List_of_Services"
    ADD CONSTRAINT id_customer FOREIGN KEY (id_customer) REFERENCES public."Customer"("ID_Customer");


--
-- Name: Cleaning id_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Cleaning"
    ADD CONSTRAINT id_employee FOREIGN KEY (id_employee) REFERENCES public."Hotel_Employee"("ID_Employee");


--
-- Name: Contract id_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Contract"
    ADD CONSTRAINT id_employee FOREIGN KEY (id_employee) REFERENCES public."Hotel_Employee"("ID_Employee");


--
-- Name:  List_of_Services id_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public." List_of_Services"
    ADD CONSTRAINT id_employee FOREIGN KEY (id_employee) REFERENCES public."Hotel_Employee"("ID_Employee");


--
-- Name: Residence id_room; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Residence"
    ADD CONSTRAINT id_room FOREIGN KEY (id_room) REFERENCES public."Room"("ID_Room");


--
-- Name: Service id_service; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Service"
    ADD CONSTRAINT id_service FOREIGN KEY (id_service) REFERENCES public." List_of_Services"(id_service);


--
-- PostgreSQL database dump complete
--

